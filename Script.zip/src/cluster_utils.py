# src/cluster_utils.py
from __future__ import annotations

from pathlib import Path
from typing import Sequence, Dict, Any, List, Optional

import numpy as np
import matplotlib.pyplot as plt

from sklearn.cluster import KMeans
from sklearn.feature_extraction.text import TfidfVectorizer

import re
import nltk
from nltk.stem import WordNetLemmatizer
from nltk.corpus import wordnet

nltk.download("wordnet")
nltk.download("omw-1.4")

lemmatizer = WordNetLemmatizer()

def custom_tokenizer(text):
    words = re.findall(r"[a-zA-Z]{3,}", text.lower())
    return [lemmatizer.lemmatize(w) for w in words]

def compute_elbow_inertia(X: np.ndarray, ks: List[int], seed: int = 42) -> List[float]:
    inertias: List[float] = []
    for k in ks:
        km = KMeans(n_clusters=k, random_state=seed, n_init=10)
        km.fit(X)
        inertias.append(float(km.inertia_))
    return inertias


def choose_k_by_max_curvature(ks: List[int], inertias: List[float]) -> int:
    """
    Simple elbow selection via max curvature (discrete 2nd difference).
    """
    if len(ks) != len(inertias) or len(ks) < 3:
        return int(ks[0])

    y = np.array(inertias, dtype=float)
    second = []
    for i in range(1, len(y) - 1):
        second.append(y[i - 1] - 2 * y[i] + y[i + 1])
    second = np.array(second)

    best_i = int(np.argmax(second)) + 1
    return int(ks[best_i])


def save_elbow_plot(ks: List[int], inertias: List[float], out_path: Path) -> None:
    out_path.parent.mkdir(parents=True, exist_ok=True)

    plt.figure()
    plt.plot(ks, inertias, marker="o")
    plt.xlabel("K")
    plt.ylabel("Inertia (KMeans)")
    plt.title("Elbow Method (Inertia vs K)")
    plt.xticks(ks)
    plt.tight_layout()
    plt.savefig(out_path, dpi=200)
    plt.close()


def fit_kmeans(X: np.ndarray, n_clusters: int, seed: int = 42) -> KMeans:
    km = KMeans(n_clusters=n_clusters, random_state=seed, n_init=10)
    km.fit(X)
    return km


def representatives_closest_to_centroid(
    X: np.ndarray,
    indices: np.ndarray,
    centroid: np.ndarray,
    texts: Sequence[str],
    top_n: int = 8,
) -> List[Dict[str, Any]]:
    """
    Pick representative documents in a cluster as those closest to centroid (Euclidean).
    """
    if indices.size == 0:
        return []

    Xc = X[indices]
    d = np.linalg.norm(Xc - centroid.reshape(1, -1), axis=1)
    order = np.argsort(d)[: min(top_n, indices.size)]

    reps: List[Dict[str, Any]] = []
    for rank, local_i in enumerate(order):
        global_i = int(indices[local_i])
        text = str(texts[global_i])
        snippet = " ".join(text.split())[:600]
        reps.append(
            {
                "global_index": global_i,
                "rank": int(rank),
                "distance": float(d[local_i]),
                "text": snippet,
            }
        )
    return reps

# A small "chatty" stopword add-on for 20NG-style posts
EXTRA_STOPWORDS = {
    "people","just","think","like","know","thanks","thank","does","dont","didnt","doesnt",
    "really","would","could","im","ive","youre","cant","wont","use","used","using",
    "time","right","good","bad","need","want","got","get","gets","say","said",
    "subject","writes","edu","com","article","lines","line","organization","don","did",
    "wa","ha"
}

def tfidf_fallback_label_contrastive(
    cluster_texts: Sequence[str],
    all_texts: Sequence[str],
    top_k: int = 10,
    label_terms: int = 3,
    *,
    stopwords_extra: Optional[Sequence[str]] = None,
) -> Dict[str, Any]:
    """
    Contrastive TF-IDF labeling:
      score(term) = mean_tfidf_in_cluster(term) - mean_tfidf_in_corpus(term)

    This favors terms that are distinctive for the cluster, not just frequent.

    Returns:
      {"label": "term1 / term2 / term3", "keywords": [...top_k...], "scores": [...top_k...]}
    """
    if len(cluster_texts) == 0:
        return {"label": "misc", "keywords": [], "scores": []}

    # Build a single vectorizer on the full corpus so vocab is shared
    extra = set(EXTRA_STOPWORDS)
    if stopwords_extra:
        extra |= set(map(str.lower, stopwords_extra))

    vec = TfidfVectorizer(
        stop_words="english",
        tokenizer=custom_tokenizer,
        max_df=0.7,          # keep more topic terms, remove super-common
        min_df=2,            # avoid "no terms remain" and keep rare-but-real topic words
        token_pattern=r"\b[a-zA-Z]{3,}\b",
        ngram_range=(1, 2),
        max_features=50000,
    )

    X_all = vec.fit_transform(all_texts)
    X_clu = vec.transform(cluster_texts)

    terms = vec.get_feature_names_out()

    # mean tfidf across docs
    all_mean = np.asarray(X_all.mean(axis=0)).ravel()
    clu_mean = np.asarray(X_clu.mean(axis=0)).ravel()

    # contrastive score
    score = clu_mean - all_mean

    # zero out extra stopwords that still slipped in
    if extra:
        term_to_idx = {t: i for i, t in enumerate(terms)}
        for w in extra:
            i = term_to_idx.get(w)
            if i is not None:
                score[i] = -np.inf

    # pick top terms
    top_idx = np.argsort(score)[::-1]
    top_idx = [i for i in top_idx if np.isfinite(score[i]) and score[i] > 0][:top_k]

    if not top_idx:
        # fallback if nothing is positive (rare)
        top_idx = np.argsort(clu_mean)[::-1][:top_k]

    keywords = [terms[i] for i in top_idx]
    scores = [float(score[i]) for i in top_idx]

    label = " / ".join(keywords[:label_terms]) if keywords else "misc"

    return {"label": label, "keywords": keywords, "scores": scores}